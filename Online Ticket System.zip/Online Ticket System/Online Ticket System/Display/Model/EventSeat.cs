﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Ticket_System.Display.Model
{
    public class EventSeat
    {
        public int evenid { get; set; }
        public int levelID { get; set; }
        public int Capacity { get; set; }
    }
}