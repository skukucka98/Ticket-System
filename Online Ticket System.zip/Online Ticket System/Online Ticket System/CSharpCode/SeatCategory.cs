﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Ticket_System.CSharpCode
{
    public class SeatCategory
    {
        public int level { get; set; }
        public int totalavailable { get; set; }
        public int totalsold { get; set; }
        public int minprice { get; set; }
    }
}